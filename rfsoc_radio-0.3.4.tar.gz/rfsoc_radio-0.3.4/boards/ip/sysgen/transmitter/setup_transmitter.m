clear; clc;
tx_data     = fi(double('Hello World!'), 0, 8, 0);